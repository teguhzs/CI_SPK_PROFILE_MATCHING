    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url('assets/admin/asset/jquery/jquery.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/admin/asset/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url('assets/admin/asset/jquery-easing/jquery.easing.min.js'); ?>"></script>

    <!-- Page level plugin JavaScript-->
    <script src="<?php echo base_url('assets/admin/asset/chart.js/Chart.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/admin/asset/datatables/jquery.dataTables.js'); ?>"></script>
    <script src="<?php echo base_url('assets/admin/asset/datatables/dataTables.bootstrap4.js'); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url('assets/admin/js/sb-admin.min.js'); ?>"></script>

    <!-- Demo scripts for this page-->
    <script src="<?php echo base_url('assets/admin/js/demo/datatables-demo.js'); ?>"></script>
    <script src="<?php echo base_url('assets/admin/js/demo/chart-area-demo.js'); ?>"></script>