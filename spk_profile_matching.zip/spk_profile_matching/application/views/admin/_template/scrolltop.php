<!-- scroll to top  -->

<a href="#page-top" class="scroll-to-top rounded">
    <i class="fa fa-angle-up"></i>
</a>