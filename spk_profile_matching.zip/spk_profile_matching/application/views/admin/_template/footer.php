        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © <?php echo SITE_NAME ." ". date('Y') ?> | <p>Halaman di render dalam <strong>{elapsed_time}</strong> detik</p></span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->